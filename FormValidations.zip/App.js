import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class App extends Component {

constructor(props) {
      super(props);
	this.state = {
         email: "",
         password: "",
	 formErrors:{"email":"Email is required","password":"Password is required"}
      }
   }

handleInput(event){
	const name = event.target.name;
	const value = event.target.value;
	this.setState({[name]:value}, 
                () => { this.validateField(name, value) });
}

validateField(fieldName, value) {
  let fieldValidationErrors = this.state.formErrors;
  switch(fieldName) {
    case 'email':
  if(value==''){
     fieldValidationErrors.email = 'Email is required';
}else{
fieldValidationErrors.email = '';
}
      break;
    case 'password':
if(value==''){
    fieldValidationErrors.password = 'Password is required';
}else{
fieldValidationErrors.password = '';
}
      break;
    default:
      break;
  }
  this.setState({formErrors: fieldValidationErrors});
}

  render() {
    return (
      <div className="App">
         <form className="demoForm">
       <h2>Sign up</h2>
       <div className="form-group">
         <label htmlFor="email">Email address</label>
         <input type="email" className="form-control"
           name="email" value={this.state.email} 
	   onChange={(event)=>this.handleInput(event)}/>
	  <ValidationError errorMessage={this.state.formErrors.email}></ValidationError>
       </div>
       <div className="form-group">
         <label htmlFor="password">Password</label>
         <input type="password" className="form-control"
           name="password" value={this.state.password}
	   onChange={(event)=>this.handleInput(event)}/>
	   <ValidationError  errorMessage={this.state.formErrors.password}></ValidationError>
       </div>
       <button type="submit" className="btn btn-primary">
          Sign up
       </button>
     </form>
      </div>
    );
  }
}

class ValidationError extends React.Component {
   render() {
if(this.props.errorMessage==''){
return '';
}else{
      return (
         <span>{this.props.errorMessage}</span>
      );
   }
 }
}

export default App;
